The following files were generated for 'myCounter' in directory 
D:\Proyecto Radar CSB\Doppler RDA\FPGA\Doppler\S Band\FPGA3_new\ISE\:

myCounter.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

myCounter.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

myCounter.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

myCounter.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

myCounter.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

myCounter.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

myCounter_c_counter_binary_v8_0_xst_1.ngc_xst.xrpt:
   Please see the core data sheet.

myCounter_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

myCounter_readme.txt:
   Text file indicating the files generated and how they are used.

myCounter_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

